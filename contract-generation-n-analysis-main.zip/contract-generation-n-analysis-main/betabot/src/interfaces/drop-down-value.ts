export default interface DropdownValue {
  name: string;
  value: string;
  selected: boolean;
}
