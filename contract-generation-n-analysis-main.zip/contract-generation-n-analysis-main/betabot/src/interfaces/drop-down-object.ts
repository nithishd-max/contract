import DropdownValue from './drop-down-value';

export default interface DropDownObject {
  label: string;
  dropdownValues: DropdownValue[];
}
