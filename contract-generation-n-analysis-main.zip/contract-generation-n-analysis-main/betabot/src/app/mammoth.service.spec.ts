import { TestBed } from '@angular/core/testing';

import { MammothService } from './mammoth.service';

describe('MammothService', () => {
  let service: MammothService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MammothService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
