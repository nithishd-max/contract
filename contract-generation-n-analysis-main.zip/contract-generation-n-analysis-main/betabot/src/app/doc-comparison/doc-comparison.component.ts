import { Component, ElementRef, ViewChild, OnInit } from '@angular/core';
import { MammothService } from '../mammoth.service';
import { DocUtilService } from '../doc-util.service';
import { BetabotApiService } from '../betabot-api.service';

@Component({
    selector: 'app-doc-comparison',
    templateUrl: './doc-comparison.component.html',
    styleUrls: ['./doc-comparison.component.scss'],
})
export class DocComparisonComponent implements OnInit {
    doc1: string = '';
    doc2: string = '';
    errorMessage: string = '';
    file1!: File;
    file2!: File;
    opFile1Path: string = '';
    opFile2Path: string = '';
    showLoader: boolean = false;
    showDocView: boolean = false;
    uploadError: boolean = false;
    invalidFileError: boolean = false;

    @ViewChild('fileInput1', { static: false })
    fileInput1!: ElementRef;

    @ViewChild('fileInput2', { static: false })
    fileInput2!: ElementRef;

    constructor(private mammoth: MammothService, private docUtility: DocUtilService,
        private api: BetabotApiService) {
    }

    ngOnInit() {
        document.getElementById('panel1')?.addEventListener('scroll', function () {
            console.log(this.scrollTop);
            document.getElementById('panel2')?.scrollTo(0, this.scrollTop);
        })
        document.getElementById('panel2')?.addEventListener('scroll', function () {
            document.getElementById('panel1')?.scrollTo(0, this.scrollTop);
        })
    }

    compareDocuments() {
        this.invalidFileError = false;
        this.showLoader = true;
        this.showDocView = false;
        if (this.fileInput1.nativeElement.value == '' || this.fileInput2.nativeElement.value == '') {
            this.invalidFileError = true;
            this.showLoader = false;
            this.errorMessage = "Please upload both the files.";
            return;
        }
        else {
            this.invalidFileError = false;
        }
        this.api.compareContracts(this.file1, this.file2).subscribe((data: any) => {
            this.opFile1Path = "../../assets/" + data.file1;
            this.opFile2Path = "../../assets/" + data.file2;
        }, (err) => {
            this.invalidFileError = true;
            this.showDocView = false;
            this.showLoader = false;
            this.errorMessage = "Comparing contracts failed. Please try again later.";
        }, () => {
            this.viewFile(this.opFile1Path, this.opFile2Path);
        });
    }

    viewFile(path1: string, path2: string) {
        this.docUtility.convertDocxToHtml(path1).subscribe(
            async (data: any) => {
                const result = await this.mammoth.convertDataToHighlightedHtml(data);
                this.doc1 = result.value;
            },
            (err) => {
                this.invalidFileError = true;
                this.showDocView = false;
                this.showLoader = false;
                this.errorMessage = "Comparing contracts failed. Please try again later.";
            }, () => {
                this.docUtility.convertDocxToHtml(path2).subscribe(
                    async (data: any) => {
                        const result = await this.mammoth.convertDataToHighlightedHtml(data);
                        this.doc2 = result.value;
                    },
                    (err) => {
                        this.invalidFileError = true;
                        this.showDocView = false;
                        this.showLoader = false;
                        this.errorMessage = "Comparing contracts failed. Please try again later.";
                    }, () => {
                        this.showDocView = true;
                        this.showLoader = false;
                    }
                );
            }
        );

    }

    readFile1(fileEvent: any) {
        this.showLoader = true;
        this.uploadError = false;
        this.file1 = fileEvent.target.files[0];
        let fileTypes = ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        if (!fileTypes.includes(this.file1.type)) {
            this.fileInput1.nativeElement.value = '';
            this.showLoader = false;
            this.uploadError = true;
            return;
        }
        this.showLoader = false;
    }

    readFile2(fileEvent: any) {
        this.showLoader = true;
        this.uploadError = false;
        this.file2 = fileEvent.target.files[0];
        let fileTypes = ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        if (!fileTypes.includes(this.file2.type)) {
            this.fileInput2.nativeElement.value = '';
            this.showLoader = false;
            this.uploadError = true;
            return;
        }
        this.showLoader = false;
    }
}
