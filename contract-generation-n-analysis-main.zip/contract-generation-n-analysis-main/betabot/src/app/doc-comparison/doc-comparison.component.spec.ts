import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocComparisonComponent } from './doc-comparison.component';

describe('DocComparisonComponent', () => {
  let component: DocComparisonComponent;
  let fixture: ComponentFixture<DocComparisonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DocComparisonComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(DocComparisonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
