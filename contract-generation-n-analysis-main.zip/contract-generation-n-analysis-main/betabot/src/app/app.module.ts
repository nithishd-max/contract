import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { DocGenComponent } from './doc-gen/doc-gen.component';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { DocAnalyzerComponent } from './doc-analyzer/doc-analyzer.component';
import { DocComparisonComponent } from './doc-comparison/doc-comparison.component';
import { AutosizeModule } from 'ngx-autosize';
import { NgxEditorModule } from 'ngx-editor';
import { ErrorPageComponent } from './error-page/error-page.component';
import { DropdownComponent } from './dropdown/dropdown.component';
import { HttpClientModule } from '@angular/common/http';
import { NoSanitizePipe } from './no-sanitize.pipe';
import { LoaderComponent } from './loader/loader.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    DocGenComponent,
    DocAnalyzerComponent,
    DocComparisonComponent,
    ErrorPageComponent,
    DropdownComponent,
    NoSanitizePipe,
    LoaderComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    AutosizeModule,
    NgxEditorModule,
    HttpClientModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
