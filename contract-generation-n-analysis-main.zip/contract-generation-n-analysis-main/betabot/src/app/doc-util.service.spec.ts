import { TestBed } from '@angular/core/testing';

import { DocUtilService } from './doc-util.service';

describe('DocUtilService', () => {
  let service: DocUtilService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DocUtilService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
