import { TestBed } from '@angular/core/testing';

import { BetabotApiService } from './betabot-api.service';

describe('BetabotApiService', () => {
  let service: BetabotApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BetabotApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
