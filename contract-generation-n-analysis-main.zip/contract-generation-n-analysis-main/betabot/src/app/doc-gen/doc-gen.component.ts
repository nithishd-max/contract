import { of } from 'rxjs';
import { BetabotApiService } from '../betabot-api.service';
import { Component, OnInit, ViewEncapsulation, OnDestroy } from '@angular/core';
import { DocUtilService } from '../doc-util.service';
import { DROPDOWN_MENUS, DEFAULT_FILE_NAME, EDITOR_TOOLBAR } from '../../utilities/constants';
import { Editor, Toolbar } from 'ngx-editor';
import { MammothService } from '../mammoth.service';
import DropDownObject from 'src/interfaces/drop-down-object';
import Utils from '../../utilities/utils';

@Component({
    selector: 'app-doc-gen',
    templateUrl: './doc-gen.component.html',
    styleUrls: ['./doc-gen.component.scss'],
    encapsulation: ViewEncapsulation.None,
})
export class DocGenComponent implements OnInit, OnDestroy {
    dropdownMenus: DropDownObject[] = DROPDOWN_MENUS;
    editor!: Editor;
    errorMessage: string = '';
    fileName: string = DEFAULT_FILE_NAME;
    generatedDocumentContent: any = '';
    invalidError: boolean = false;
    queryMessage: string = '';
    showLoader: boolean = false;
    successfulGeneration: boolean = false;
    toolbar: Toolbar = EDITOR_TOOLBAR;
    newRules: any = {}
    referenceDoc: boolean = false;

    ngOnInit() {
        this.editor = new Editor();
        this.api.getTemplates().subscribe((data: any) =>{
            for(let dropdown of this.dropdownMenus){
                if(dropdown.label === 'Select Template'){
                    dropdown.dropdownValues.push({ name: "Select a Template", value: "", selected: true })
                    for(let dataValue of data.templates){
                        dropdown.dropdownValues.push({ name: dataValue, value: dataValue, selected: false })
                    }
                }
            }
        });
    }

    ngOnDestroy() {
        this.editor.destroy();
    }

    constructor(
        private api: BetabotApiService,
        private docUtility: DocUtilService,
        private mammoth: MammothService
    ) { }

    clearQuery() {
        this.queryMessage = '';
    }

    generateDocument() {
        let temp = Utils.selectedDropdowns(this.dropdownMenus)[1];
        this.errorMessage = '';
        this.showLoader = true;
        this.successfulGeneration = false;
        this.invalidError = false;
        this.queryMessage = this.queryMessage.replace(/ {2,}/g, ' ').trim();
        if (this.queryMessage.length < 10) {
            this.showError('Please enter a query with a minimum of 10 letters.');
            return;
        }
        if(temp.selectedValue === ''){
            this.showError('Please select a template.');
            return;
        }
        let data = {
            "document_type": Utils.selectedDropdowns(this.dropdownMenus)[0].selectedValue,
            "query": this.queryMessage,
            "newRules": this.newRules,
            "template": Utils.selectedDropdowns(this.dropdownMenus)[1].selectedValue,
            "useReferenceDoc": this.referenceDoc
        }
        this.api.generateContract(data).subscribe(
            (data) => {
                this.convertDocxToHtml("../../assets/" + data.file);
            },
            (err) => {
                this.showError('Failed to generate the contract. Please try again.');
            }
        );
    }

    async downloadDocument() {
        let filename: string = '';
        if (this.fileName === '') {
            filename = DEFAULT_FILE_NAME;
        }
        filename = this.fileName + '.docx';
        await this.docUtility.downloadDocument(this.generatedDocumentContent, filename);
    }

    convertDocxToHtml(filePath: string) {
        this.generatedDocumentContent = '';
        this.docUtility.convertDocxToHtml(filePath).subscribe(
            async (data: any) => {
                const result = await this.mammoth.convertDataToHtml(data);
                this.generatedDocumentContent = result.value;
            },
            (err) => {
                this.showError('Failed to generate the contract. Please try again.');
            },
            () => {
                this.successfulGeneration = true;
                this.showLoader = false;
            }
        );
    }

    showError(errorMessage: string) {
        this.invalidError = true;
        this.successfulGeneration = false;
        this.showLoader = false;
        this.errorMessage = errorMessage;
    }
}
