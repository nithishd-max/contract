import { Component } from '@angular/core';
import { NAVIGATION_MENU } from '../../utilities/constants';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent {
  brandTitle = 'BetaBot';

  navigationMenu = NAVIGATION_MENU;

  toggleMobileMenu() {
    let menu: HTMLElement = document.getElementById('navbar-default') as HTMLElement;
    menu.classList.toggle('hidden');
  }
}
