import { Component, ViewChild, ElementRef } from '@angular/core';
import { BetabotApiService } from '../betabot-api.service';
import { MammothService } from '../mammoth.service';
import { DocUtilService } from '../doc-util.service';

@Component({
    selector: 'app-doc-analyzer',
    templateUrl: './doc-analyzer.component.html',
    styleUrls: ['./doc-analyzer.component.scss'],
})
export class DocAnalyzerComponent {
    file!: File;
    htmlContent: string = '';
    modalData: string = '';
    showLoader: boolean = false;
    successfullyAnalyzed: boolean = false;
    uploadError: Boolean = false;
    opFilePath: string = '';
    analyzeError: boolean = false;
    errorMessage: string = '';
    doc1: string = '';

    @ViewChild('fileInput', { static: false })
    fileInput!: ElementRef;

    constructor(private api: BetabotApiService, private mammoth: MammothService, private docUtility: DocUtilService,) { }

    closeModal() {
        document.getElementById('modal')?.classList.add('hidden');
        this.modalData = '';
    }

    readFile(fileEvent: any) {
        this.showLoader = true;
        this.uploadError = false;
        this.file = fileEvent.target.files[0];
        let fileTypes = ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
        if (!fileTypes.includes(this.file.type)) {
            this.fileInput.nativeElement.value = '';
            this.showLoader = false;
            this.uploadError = true;
            return;
        }
        if (
            document.getElementById('analyzed-result') !== null ||
            document.getElementById('analyzed-result') !== undefined
        ) {
            this.analyzedResult();
        }
    }

    analyzedResult() {
        this.api.analyzeContract(this.file).subscribe((data: any) => {
            this.opFilePath = "../../assets/" + data.file;
        }, (err) => {
            this.showLoader = false;
            this.analyzeError = true;
            this.errorMessage = "Analyzing contracts failed. Please try again later.";
        }, () => {
            this.viewFile(this.opFilePath);
        });
    }
    viewFile(path1: string) {
        this.docUtility.convertDocxToHtml(path1).subscribe(
            async (data: any) => {
                const result = await this.mammoth.convertDataToHighlightedHtml(data);
                this.doc1 = result.value;
            },
            (err) => {
                this.showLoader = false;
                this.analyzeError = true;
                this.errorMessage = "Analyzing contracts failed. Please try again later.";
            }, () => {
                this.successfullyAnalyzed = true;
                this.showLoader = false;
            }
        );

    }
}
