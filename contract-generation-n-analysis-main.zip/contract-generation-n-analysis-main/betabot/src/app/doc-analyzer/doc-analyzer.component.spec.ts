import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocAnalyzerComponent } from './doc-analyzer.component';

describe('DocAnalyzerComponent', () => {
  let component: DocAnalyzerComponent;
  let fixture: ComponentFixture<DocAnalyzerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DocAnalyzerComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(DocAnalyzerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
