import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { BASE_URL } from '../utilities/constants';

@Injectable({
    providedIn: 'root',
})
export class BetabotApiService {
    constructor(private http: HttpClient) { }

    getTemplates() {
        const url = BASE_URL + '/get_templates';
        return this.http.get(url);
    }

    getSections(templateName: string) {
        const url = BASE_URL + '/get_template/' + templateName;
        return this.http.get(url);
    }

    generateContract(data: any): Observable<any> {
        const url = BASE_URL + '/generate_content';
        return this.http.post(url, data);
    }

    analyzeContract(data: any): Observable<any> {
        const url = BASE_URL + '/analyze_document';
        const formdata = new FormData();
        formdata.append('file', data, data.name);
        return this.http.post(url, formdata);
    }

    compareContracts(file1: any, file2: any): Observable<any> {
        const url = 'http://127.0.0.1:5000/compare_documents';
        const formdata = new FormData();
        formdata.append('file1', file1, file1.name);
        formdata.append('file2', file2, file2.name);
        return this.http.post(url, formdata);
    }
}
