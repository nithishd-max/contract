import { Component, Input, OnInit } from '@angular/core';
import DropDownObject from 'src/interfaces/drop-down-object';
import { BetabotApiService } from '../betabot-api.service';
import { ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { throws } from 'assert';

@Component({
    selector: 'app-dropdown',
    templateUrl: './dropdown.component.html',
    styleUrls: ['./dropdown.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class DropdownComponent implements OnInit {
    @Input()
    dropDownObj: DropDownObject = {} as DropDownObject;
    selectedSection: string = '';
    newRule: string = '';
    selectedValue: string = '';
    sections: any = [];
    viewModal: boolean = false;
    viewRulesModal: boolean = false;
    invalidError: boolean = false;
    errorMessage: string = '';

    @Input()
    newRules: any = {}

    constructor(private api: BetabotApiService, private cdr: ChangeDetectorRef) {
    }

    ngOnInit(): void {
        for (let obj of this.dropDownObj.dropdownValues) {
            if (obj.selected) {
                this.selectedValue = obj.value;
                break;
            }
        }
    }

    dropdownChange() {
        for (let obj of this.dropDownObj.dropdownValues) {
            if (this.selectedValue === obj.value) {
                obj.selected = true;
            } else {
                obj.selected = false;
            }
        }
        this.api.getSections(this.selectedValue).subscribe((data: any) => {
            this.sections = data.sections;
            this.cdr.detectChanges();
            this.cdr.markForCheck();
        }, (err) => {
            console.log(err);
        });
    }

    openSectionModal() {
        this.viewModal = true;
    }

    closeSectionModal() {
        this.viewModal = false;
    }

    openRulesModal(){
        this.viewRulesModal = true;
    }

    closeRulesModal(){
        this.viewRulesModal = false;
    }

    addNewRule(){
        this.invalidError = false;
        if(this.selectedSection === ''){
            this.invalidError = true;
            this.errorMessage = "Please select a section."
            return;
        }
        if(this.newRule === ''){
            this.invalidError = true;
            this.errorMessage = "Please enter a rule description."
            return;
        }
        this.newRule = this.newRule.replace(/ {2,}/g, ' ').trim();
        if(this.newRule.length < 10){
            this.invalidError = true;
            this.errorMessage = "Please enter a rule description with a minimum of 10 letters."
            return;
        }
        this.newRules[this.selectedSection] = this.newRule;
        this.newRule = '';
        this.closeRulesModal();
        //Post to the rules database for the corresponding section;
    }
}
