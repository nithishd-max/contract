import { Injectable } from '@angular/core';
const mammoth = require('mammoth/mammoth.browser');

@Injectable({
    providedIn: 'root',
})
export class MammothService {
    result: any;

    options = {
        styleMap: [
            "u => p.bg-yellow-500.inline-block"
        ]
    };

    constructor() { }

    async convertDataToHtml(data: any) {
        this.result = await mammoth.convertToHtml({ arrayBuffer: data });
        return this.result;
    }

    async convertDataToHighlightedHtml(data: any) {
        this.result = await mammoth.convertToHtml({ arrayBuffer: data }, this.options);
        return this.result;
    }
}
