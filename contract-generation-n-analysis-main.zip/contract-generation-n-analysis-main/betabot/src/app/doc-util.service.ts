import { Injectable } from '@angular/core';
import { FileService } from './file.service';
import { asBlob } from 'html-docx-js-typescript';
import { saveAs } from 'file-saver';

@Injectable({
  providedIn: 'root',
})
export class DocUtilService {
  constructor(private file: FileService) {}

  convertDocxToHtml(inputDocPath: string) {
    return this.file.getArrayBuffer(inputDocPath);
  }

  async downloadDocument(content: any, fileName: string) {
    const converted = await asBlob(content);
    saveAs(converted as Blob, fileName);
  }
}
