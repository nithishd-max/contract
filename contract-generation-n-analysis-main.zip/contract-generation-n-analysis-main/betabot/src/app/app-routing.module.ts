import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DocGenComponent } from './doc-gen/doc-gen.component';
import { DocAnalyzerComponent } from './doc-analyzer/doc-analyzer.component';
import { DocComparisonComponent } from './doc-comparison/doc-comparison.component';
import { ErrorPageComponent } from './error-page/error-page.component';

const routes: Routes = [
  { path: 'contract-generator', component: DocGenComponent },
  { path: 'contract-analyzer', component: DocAnalyzerComponent },
  { path: 'contract-comparison', component: DocComparisonComponent },
  { path: '', redirectTo: '/contract-generator', pathMatch: 'full' },
  { path: '**', component: ErrorPageComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
