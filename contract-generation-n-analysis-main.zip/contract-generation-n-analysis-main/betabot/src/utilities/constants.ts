import { Toolbar } from 'ngx-editor';

export const DROPDOWN_MENUS = [
  {
    label: 'Type of Document',
    dropdownValues: [
      { name: 'Contract', value: 'Contract', selected: true },
      { name: 'PO', value: 'PO', selected: false },
      {
        name: 'Invoices with Special Notes',
        value: 'Invoices with Special Notes',
        selected: false,
      },
    ],
  },
  {
    label: 'Select Template',
    dropdownValues: [],
  },
];

export const DEFAULT_FILE_NAME = 'GeneratedContract';

export const BASE_URL = 'http://127.0.0.1:5000';

export const NAVIGATION_MENU = [
  {
    routeName: 'Contract Generator',
    routeLink: '/contract-generator',
  },
  {
    routeName: 'Contract Analyzer',
    routeLink: '/contract-analyzer',
  },
  {
    routeName: 'Contract Comparator',
    routeLink: '/contract-comparison',
  },
];

export const EDITOR_TOOLBAR: Toolbar = [
  ['bold'],
  ['underline'],
  ['text_color', 'background_color'],
  ['align_left', 'align_center', 'align_right', 'align_justify'],
];
