import DropDownObject from 'src/interfaces/drop-down-object';

export default class Utils {
  static selectedDropdowns(dropdownMenus: DropDownObject[]) {
    const selectedDropdown: any[] = [];
    for (let dropdownMenu of dropdownMenus) {
      for (let dropdownValue of dropdownMenu.dropdownValues) {
        if (dropdownValue.selected === true) {
          selectedDropdown.push({
            selectedDropdown: dropdownMenu.label,
            selectedValue: dropdownValue.value,
          });
        }
      }
    }
    return selectedDropdown;
  }
}
