import pandas as pd

from base import WordDocument,VectorStore,make_highlighted_comparison_docs
from constants import HF_EMBEDDINGS,COMPARISION_OUT_ABS_PATH1,COMPARISION_OUT_ABS_PATH2

def hightlight_rules(docs):
    # df_full=pd.DataFrame(columns=["row","section","document1","document2","score"])
    df_sim=pd.DataFrame(columns=["row","section","document1","document2","score"])
    df_diff=pd.DataFrame(columns=["row","section","document1","document2","score"])
    i=0;j=0
    for doc in docs:
        # df_full.loc[i+j]={"row":(i+j),"section":doc[0].metadata["section"],"document1":doc[0].page_content,"document2":doc[1][0].page_content,"score":[doc[1][1]]}
        if doc[1][1]<0.3:
            df_sim.loc[i]={"row":(i),"section":doc[0].metadata["section"],"document1":doc[0].page_content,"document2":doc[1][0].page_content,"score":[doc[1][1]]}
            i+=1
        else:
            df_diff.loc[j]={"row":(j),"section":doc[0].metadata["section"],"document1":doc[0].page_content,"document2":doc[1][0].page_content,"score":[doc[1][1]]}
            j+=1
    df_sim=df_sim.groupby(['section'],as_index=False,sort=False).aggregate('sum')
    df_diff=df_diff.groupby(['section'],as_index=False,sort=False).aggregate('sum')
    file_name = "../inputs-outputs/comparision/Comparision-similar-results.csv"
    file_name1 = "../inputs-outputs/comparision/Comparision-difference-results.csv"
    df_sim.to_csv(file_name,index=False)
    df_diff.to_csv(file_name1,index=False)
    return (df_sim,df_diff)

def comparator(file1,file2,*args):
    mydoc1 = WordDocument(file1).setup()
    mydoc2 = WordDocument(file2).setup()
    similar_docs=[]
    file2vdb = VectorStore().from_documents(mydoc2.docs,HF_EMBEDDINGS).vector_store
    for doc in mydoc1.docs:
        matched_docs=file2vdb.similarity_search_with_score(doc.page_content,k=1,fetch_k=400,filter={"section":doc.metadata["section"]})
        if len(matched_docs)==0:
            print("filter didn't work",doc.metadata["section"])
            matched_docs=file2vdb.similarity_search_with_score(doc.page_content,k=1)
        similar_docs.append((doc,matched_docs[0]))
    res = hightlight_rules(similar_docs)
    make_highlighted_comparison_docs(COMPARISION_OUT_ABS_PATH1,COMPARISION_OUT_ABS_PATH2,mydoc1,mydoc2,res[1])
    return (COMPARISION_OUT_ABS_PATH1.split('\\')[-1],COMPARISION_OUT_ABS_PATH2.split('\\')[-1])