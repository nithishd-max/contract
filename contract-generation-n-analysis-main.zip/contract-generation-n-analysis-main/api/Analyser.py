import os
import requests
import pandas as pd
from datetime import datetime

from base import (CustLLMChain,
                  VectorStore,
                  WordDocument,
                  refine_content,
                  make_highlighted_analyzed_doc,
                  make_abspath,
                  get_few_lines)

from constants import (RULES_VDB_ABS_PATH,
		       		   LLM,
                       RULES_PROMPT_TEMPLATE,
                       HF_EMBEDDINGS,
                       ANALYSIS_OUT_ABS_PATH,
                       API_BASE_URL
                       )

rules_vdb = VectorStore(RULES_VDB_ABS_PATH,HF_EMBEDDINGS)

rule_chain=CustLLMChain(llm=LLM,prompt=RULES_PROMPT_TEMPLATE)

def get_rules(rule_id):
    url = API_BASE_URL+f"get_rules/{rule_id}"
    res = requests.get(url)
    res = res.json()["rules"][0]
    return res

def extract_rules(docs,demo,part_demo):
    log = open(make_abspath(r"logs\analyze-logs.txt"),"a")
    rules_found,visited_sections=[],[]
    sep="\n"+"---"*20+"\n"
    ignore_section=["ownerdetails","sellers","buyers","contractdate"]
    
    df=pd.DataFrame(columns=["section","content","rules","rule_id"])
    i=0
    for doc in docs[:]:
        if part_demo and i==part_demo: break
        
        if doc.metadata["section"] in visited_sections: continue
        
        if doc.metadata["section"] in ignore_section:
            log.write(f"{doc.metadata['section']}{sep} Ignored this section\n")
            continue
        log.write(doc.metadata["section"]+sep)

        matched_rules = rules_vdb.similarity_search(doc.page_content,k=1)
        rule=matched_rules[0].metadata["rule_id"]
        if rule in rules_found:
            log.write(f"Rule {rule}:\n{sep} Already found\n")
            continue
        #request call to get the rules
        rules=get_rules(rule)
        log.write(f"Rule {rule}:\n{sep}{rules}")

        start = datetime.now()
        if demo: extracted_rules = rules
        else: extracted_rules=rule_chain(context=matched_rules[0].page_content,rules=rules,query_context=doc.page_content)
        
        
        log.write("Extracted Rules:\n"+sep+'\n'+extracted_rules)
        log.write("Time taken: "+str(datetime.now()-start))

        extracted_rules = refine_content(extracted_rules)
        log.write("Refined Rules:\n"+sep+extracted_rules)

        if len(extracted_rules)==0: log.write("No content\n");continue

        df.loc[i]={"section":doc.metadata["section"],"content":get_few_lines(doc.page_content,4),"rules":extracted_rules,"rule_id":rule}
        rules_found.append(rule)
        visited_sections.append(doc.metadata["section"])
        i+=1

    # file_path = r"inputs-outputs\analysis\RuleExtractor.csv"
    # df.to_csv(file_path,index=False)
    log.close()
    return (df)


def analyze(file_path,demo=False,part_demo=False):
    if not demo is False: demo = True
    if not part_demo is False:
        try: part_demo = int(part_demo)
        except: part_demo = 4
    print("Analyzing...")
    start = datetime.now()
    mydoc=WordDocument(file_path)
    mydoc.setup()
    res = extract_rules(mydoc.docs,demo=demo,part_demo=part_demo)
    print("Analysis Done")
    print("\tTime taken: ",str(datetime.now()-start))
    
    start = datetime.now()
    print("Generating highlighted document")
    make_highlighted_analyzed_doc(df=res,sections=mydoc.sections,contents=mydoc.contents,save_path=ANALYSIS_OUT_ABS_PATH)
    print("\tTime taken: ",str(datetime.now()-start))

    # log.write("Time taken: "+str(datetime.now()-start))
    # log.close()
    return (ANALYSIS_OUT_ABS_PATH.split('\\')[-1])
