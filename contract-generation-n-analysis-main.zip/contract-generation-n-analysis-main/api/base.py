import re
import os

from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import FAISS

import pandas as pd
from datetime import datetime
from bs4 import BeautifulSoup
import mammoth
from docx import Document as DocxDocument
from docx.enum.text import WD_COLOR_INDEX
from docx.shared import Pt,RGBColor

LIST_OF_OPEN_FILES = []

print("Importing BASE")


def try_catch(func):
    def inner(*args,**kwargs):
        try:
            ex=None
            res = func(*args,**kwargs)
            return res
        except Exception as e:
            ex=e
            print("Exception occured:",(e.__traceback__))
            print("func",func.__name__)
            # res = ex
        finally:
            for file in LIST_OF_OPEN_FILES:
                if not file.closed: file.close()
            LIST_OF_OPEN_FILES.clear()
            if ex: raise ex
            return res
    return inner

def open_file(*args,**kwargs):
    file = open(*args,**kwargs)
    LIST_OF_OPEN_FILES.append(file)
    return file
  

class VectorStore:
    def __init__(self,vdb_path=None,embeddings=None):
        self.embeddings = embeddings
        self.path = vdb_path
        if vdb_path: self.load_local(vdb_path,embeddings)
    def load_local(self,vdb_path,embeddings=None):
        if not embeddings: embeddings = self.embeddings
        if os.path.exists(vdb_path):
            print("Vectore already exists locally")
            self.vector_store = FAISS.load_local(vdb_path,embeddings)
            return self
        else:
            raise ValueError(f"Vector DB doesn't exist locally at the given path: {vdb_path}")
    def from_documents(self,docs,embeddings=None):
        if not embeddings: embeddings = self.embeddings
        self.vector_store = FAISS.from_documents(docs,embeddings)
        return self
    def get_vector_store(self):
        return self.vector_store
    
    def similarity_search(self,*args,**kwargs):
        return self.vector_store.similarity_search(*args,**kwargs)
    
    def similarity_search_with_score(self,*args,**kwargs):
        return self.vector_store.similarity_search_with_score(*args,**kwargs)
    
    def get_section_content(self,section,template=None,max_words=None,return_only_docs=False):
        section = section.replace(" ","").lower()
        docs=[]
        if not template is None:
            docs = self.vector_store.similarity_search("find the section - "+section,fetch_k=1000,filter={"template":template,"section":section})
        if len(docs)==0:
            # print("section+template filter didn't work")
            docs = self.vector_store.similarity_search("find the section - "+section,k=3,fetch_k=1000,filter={"section":section})
        if len(docs)==0 and not template is None:
            # print("section filter didn't work")
            docs = self.vector_store.similarity_search("find the section - "+section,k=3,fetch_k=1000,filter={"template":template})
        if len(docs)==0:
            # print("none of the filters worked")
            docs = self.vector_store.similarity_search("find the section - "+section,k=2)
        
        if return_only_docs: return docs

        content=''
        for doc in docs:
            content+='\n'+doc.page_content
        if not max_words: return content
        print("Stripping the content to max_words:",max_words)
        content = content.split()
        content1 = content[:max_words]
        end_pattern = r"[^a-zA-Z\d\s:]"
        if re.match(end_pattern,content1[-1][-1]) or '\n' not in content1[-1] :
            for i in range(max_words,len(content)):
                content1.append(content[i])
                if re.match(end_pattern,content[i][-1]) or '\n' in content1[-1]: break
        content = ' '.join(content1)
        return content

class WordDocument:
    def __init__(self,path,template='',text_splitter=None):
        self.path = path
        self.template = template
        self.text_splitter = text_splitter
        if not self.text_splitter:
            self.text_splitter = RecursiveCharacterTextSplitter(chunk_size=800,chunk_overlap=50)
        self.html=''
        self.contents=[]
        self.sections=[]
        self.docs = []
    def setup(self):
        self.html = self._get_html_from_docx()
        self.sections,self.contents = self._get_sectionwise_content_from_html()
        self.docs = self._get_langchain_documents()
        return self
    def _get_html_from_docx(self):
        if self.html: return self.html
        with open(self.path, "rb") as docx_file:
            result = mammoth.convert_to_html(docx_file)
            self.html = result.value
            # messages = result.messages # Any messages, such as warnings during conversion
            return self.html

    def _get_sectionwise_content_from_html(self):
        if self.sections and self.contents: return self.sections,self.contents
        all_content=[]
        sections=['OwnerDetails']
        section_content=''
        ignore_codes = ['Alert','ICLM_IntSignature',"ICLM_ExtSignature"]
        soup = BeautifulSoup(self.html)
        for e in soup.find_all(string=True, recursive=True):
            if e.text=='' or e.text==None: continue
            is_content=True
            if e.parent.name == 'strong' or e.parent.name == 'b':
                text = e.text.replace(' ','')
                if text.endswith(':'):
                    is_content=False
                    # print("section:",e.text)
                    sections.append(e.text.strip()[:-1])
                    section_content = re.sub(r'\n\s*\n', '\n\n', section_content)
                    all_content.append(section_content)
                    section_content = '\n'
            if is_content:
                # print("sub-section:",e.text)
                if any(x in e.text for x in ignore_codes):
                    # print(e.text.strip()[:20],"ignored")
                    continue
                section_content += e.text+'\n'
        section_content = re.sub(r'\n\s*\n', '\n\n', section_content)
        all_content.append(section_content)
        return sections,all_content
    
    def _get_langchain_documents(self,split=True):
        if self.docs: return self.docs
        file = self.path.split("\\")[-1]
        self.docs = []
        ignore_sections=["For the Sellers","For the Buyers"]
        for section,content in zip(self.sections,self.contents):
            if section in ignore_sections:
                # print("section:",section,": ignored")
                continue
            section = section.lower().replace(" ","")
            metadata = {"section":section,"source":file,"template":self.template}
            doc = Document(page_content=content,metadata=metadata.copy())
            self.docs.append(doc)
        if split:
            self.docs = self.text_splitter.split_documents(self.docs)
        return self.docs

def CustLLMChain(llm, prompt):
    prompt_inputs = prompt.input_variables
    def run(*args,**kwargs):
        if args and kwargs:
            raise ValueError("Only pass either args or kwargs")
        if args:
            kwargs.update(dict(zip(prompt_inputs,args)))
        input_query = prompt.format(**kwargs)
        return llm(input_query)
    return run

def rules_loader_from_csv(url,**kwargs):
    df = pd.read_csv(url,**kwargs)
    cols = list(df.columns)
    docs=[]
    metadata = {"source": url, "date": datetime.now().date()}
    
    for i in range(df.shape[0]):
        content = [f"{col}\n:{val}\n" for col,val in zip(cols,df.iloc[i])]
        content = '\n'.join(content)
        metadata1 = metadata.copy()
        metadata1["rule_clause"]=df["Clause Nos"].iloc[i]
        metadata1["section_name"]=df["Content Section Name"].iloc[i]
        docs.append(Document(page_content=content,metadata=metadata))
    return docs


def refine_content(content,party_details=None,ignore_list=[]):
    if not party_details is None:
        party_details = party_details.split("\n")
        party_details = [p.strip() for p in party_details]
        ignore_list.extend(party_details)
    ignore_list.extend(["rules:","\end{code}","\begin{code}"])
    content = re.sub(r'\n\s*\n', '\n\n',content)
    # if len(ignore_list)==0: return content
    for ig in ignore_list:
        content = content.replace(ig,"")
    if "begin" in content:
        flag=True
        while flag:
            start_idx = content.find("\begin")
            end_idx = content.find("\end")
            if start_idx==-1 or end_idx==-1: flag=False
            else:
                content = content[:start_idx]+content[end_idx+4:]

    content = re.sub(r'\n\s*\n', '\n\n',content)
    return content

# ===========================================================================================
make_abspath = lambda x: os.path.abspath(os.path.join(__file__,'../../',x))
strip_extra_spaces = lambda x: re.sub(r'\n\s*\n', '\n',x)
get_few_lines = lambda x,n=10: strip_extra_spaces('\n'.join(x.split('\n')[:n]))


def add_run(para,text,bold=False,highlight=False,super_script=False,add_new_line=False):
    text = strip_extra_spaces(text)
    if not add_new_line:
        if text.endswith("\n"): text = text[:-1]
    else:
        if not text.endswith("\n") or len(text)==0: text+="\n"
    
    run = para.add_run(text)
    run.font.name="Verdana"
    run.font.size=Pt(10)
    if bold: run.bold=True
    if highlight!=False:
        run.font.highlight_color = highlight
        run.underline=True
    if super_script: run.font.superscript=True
    return


def make_docx_file(save_path,sections,contents):
    doc = DocxDocument()
    # para_format = doc.styles['Normal'].paragraph_format
    for section,content in zip(sections,contents):
        para = doc.add_paragraph("")
        para.space_before = Pt(0)
        add_run(para,section+":\n",bold=True)
        add_run(para,content)
    doc.save(save_path)
    print("Document Saved successfully")
    return
def _comapre_and_highlight_for_analyzer(para,content,df_section):
    highlighted=False
    for i in range(len(df_section)):
        st_idx = content.find(df_section["content"].iloc[i][:25])
        end_idx = content.find(df_section["content"].iloc[i][-25:])
        if end_idx==-1: end_idx = 100
        end_idx+=25
        if st_idx==-1:
            # add_run(para,"\n"+content)
            # print(section,": content not found")
            continue
        else:
            highlighted=True
            rule_id = df_section["rule_id"].iloc[0]
            # print("Highlighting")
            add_run(para,str(rule_id),highlight=WD_COLOR_INDEX.TURQUOISE)
            sc = content[:st_idx]
            add_run(para,"\n"+sc)
            sc = content[st_idx:end_idx]
            add_run(para,sc,highlight=WD_COLOR_INDEX.YELLOW)
            content = content[end_idx:]
            # add_run(para,sc)
    if highlighted==False or len(content)>0:
        add_run(para,content)

def make_highlighted_analyzed_doc(df,sections,contents,save_path):
    
    doc = DocxDocument()
    for section,content in zip(sections,contents):
        para = doc.add_paragraph("")
        para.space_before = Pt(0)
        if section==sections[0]:
            add_run(para,"\n"+content)
            continue

        add_run(para,"\n"+section+":\t",bold=True)
        modsec= section.replace(" ","").lower()
        df_section = df[df["section"]==modsec]

        if df_section.shape[0]==0:
            # print(section,": section not found")
            add_run(para,content)
            continue
        
        st_idx = content.find(df_section["content"].iloc[0][:25])
        end_idx = content.find(df_section["content"].iloc[0][-25:])
        if end_idx==-1: end_idx = 100
        end_idx+=25
        if st_idx==-1:
            add_run(para,"\n"+content)
            # print(section,": content not found")
            continue
        else:
            rule_id = df_section["rule_id"].iloc[0]
            # print("Highlighting")
            add_run(para,str(rule_id),highlight=WD_COLOR_INDEX.TURQUOISE,add_new_line=True)
            sc = content[:st_idx]
            add_run(para,"\n"+sc)
            sc = content[st_idx:end_idx]
            add_run(para,sc,highlight=WD_COLOR_INDEX.YELLOW)
            sc = content[end_idx:]
            add_run(para,sc)
    doc.save(save_path)

def _comapre_and_highlight_for_comaparator(para,content,df_section,sim_df,diff_df):
    highlighted=False
    for i in range(len(df_section)):
        st_idx = content.find(df_section["content"].iloc[i][:25])
        end_idx = content.find(df_section["content"].iloc[i][-25:])
        if end_idx==-1: end_idx = 100
        end_idx+=25
        if st_idx==-1:
            # add_run(para,"\n"+content)
            # print(section,": content not found")
            continue
        else:
            highlighted=True
            rule_id = df_section["rule_id"].iloc[0]
            # print("Highlighting")
            add_run(para,str(rule_id),highlight=WD_COLOR_INDEX.TURQUOISE)
            sc = content[:st_idx]
            add_run(para,"\n"+sc)
            sc = content[st_idx:end_idx]
            add_run(para,sc,highlight=WD_COLOR_INDEX.YELLOW)
            content = content[end_idx:]
            # add_run(para,sc)
    if highlighted==False or len(content)>0:
        add_run(para,content)

def make_highlighted_comparison_docs(doc1,doc2,similar_df,diff_df):
    doc = DocxDocument()
    for section in doc1.sections:
        para = doc.add_paragraph("")
        add_run(para,section+":\n",bold=True)
        if section in similar_df["section"].values:
            add_run(para,similar_df[similar_df["section"]==section]["content"].iloc[0],highlight=WD_COLOR_INDEX.YELLOW)
        else:
            add_run(para,doc1.sections[section])
        add_run(para,"\n")
    doc.save("similar.docx")

    doc = DocxDocument()
    for section in doc1.sections:
        para = doc.add_paragraph("")
        para.space_before = None
        add_run(para,section+":\n",bold=True)
        if section in diff_df["section"].values:
            add_run(para,diff_df[diff_df["section"]==section]["content"].iloc[0],highlight=WD_COLOR_INDEX.YELLOW)
        else:
            add_run(para,doc1.sections[section])
        add_run(para,"\n")
    doc.save("diff.docx")


def create_pre_formatted_document():
    doc = DocxDocument()
    para_format = doc.styles['Normal'].paragraph_format
    para_format.space_before = Pt(0)
    para_format.space_after = Pt(0)
    return doc

def get_matching_slice(content,df_section,col="document1"):
    match_idxs = []
    for row in df_section.iterrows():
        st_idx = content.find(row[1][col][:25])
        end_idx = content.find(row[1][col][-25:])
        if end_idx==-1: end_idx = 100
        end_idx+=25
        if st_idx==-1:
            # print(section,": content not found")
            continue
        else:
            match_idxs.append((st_idx,end_idx,row[1]["row"]))
    return sorted(match_idxs)
def _comapre_and_highlight_section(para,content,match_idxs):
    prev=0
    for st_idx,end_idx,row in match_idxs:
        add_run(para,"\n"+content[prev:st_idx])
        add_run(para,content[st_idx:end_idx],highlight=WD_COLOR_INDEX.YELLOW)
        add_run(para,str(row),highlight=WD_COLOR_INDEX.TURQUOISE,super_script=True)
        prev=end_idx
    add_run(para,content[prev:],add_new_line=True)
    return

def _highlight_document(doc,highlight_info):
    mydoc = create_pre_formatted_document()
    for section,content in zip(doc.sections,doc.contents):
        para = mydoc.add_paragraph("")
        if section!=doc.sections[0]: add_run(para,"\n"+section+":",bold=True)
        if highlight_info.get(section) :_comapre_and_highlight_section(para,content,highlight_info[section])
        else: add_run(para,content)
    return mydoc


@try_catch
def make_highlighted_comparison_docs(save_path1,save_path2,doc1,doc2,df):
    log = open_file("../logs/comparator.log","w")
    log.write(f"Sections in doc1: {doc1.sections}\n\n")
    log.write(f"Sections in doc2: {doc2.sections}\n\n")
    doc1_highlight_info = dict()
    doc2_highlight_info = dict()
    for section,content in zip(doc1.sections,doc1.contents):
        modsec= section.replace(" ","").lower()
        df_section = df[df["section"]==modsec]
        if df_section.shape[0]==0: log.write(f"No rows found for section: {section}\n");continue
        if section not in doc2.sections: continue
        content2 = doc2.contents[doc2.sections.index(section)]

        doc1_idxs = get_matching_slice(content,df_section,col="document1")
        doc2_idxs = get_matching_slice(content2,df_section,col="document2")    

        log.write(f"{section}:\ndoc1 idxs: {str(doc1_idxs)}\n doc2 idxs: {str(doc2_idxs)}\n")
        log.write("=="*40)

        doc1_highlight_info[section] = doc1_idxs
        doc2_highlight_info[section] = doc2_idxs
    log.close()
    doc1= _highlight_document(doc1,doc1_highlight_info)
    doc2 = _highlight_document(doc2,doc2_highlight_info)
    doc1.save(save_path1)
    doc2.save(save_path2)
    return
