import os

from langchain.prompts import PromptTemplate
from langchain.embeddings import HuggingFaceEmbeddings
from ctransformers import AutoModelForCausalLM

print("Importing Constants")

API_BASE_URL = "http://localhost:5000/"

# PATHS
make_abspath = lambda x: os.path.abspath(os.path.join(__file__,'../../',x))

DB_FILE = "local-databases\contract-gen-app.db"

DB_ABS_PATH = make_abspath(DB_FILE)

REF_DOCS_VDB_PATH = r"local-databases\ref-docs-vdb-template"
REF_DOCS_VDB_ABS_PATH = make_abspath(REF_DOCS_VDB_PATH)

RULES_VDB_PATH = r"local-databases\rules-vdb-final"
RULES_VDB_ABS_PATH = make_abspath(RULES_VDB_PATH)

MODEL_PATH = r"models\llama-7b.ggmlv3.q2_K.bin"
MODEL_ABS_PATH = make_abspath(MODEL_PATH)

GEN_OUT_ABS_PATH = make_abspath(r"betabot\src\assets\generated-doc.docx")

ANALYSIS_IN_ABS_PATH = make_abspath(r"inputs-outputs\analysis\analysis_document.docx")
ANALYSIS_OUT_ABS_PATH = make_abspath(r"betabot\src\assets\analysis_output.docx")

COMPARISION_IN_ABS_PATH1 = make_abspath(r"inputs-outputs\comparision\compare_document1.docx")
COMPARISION_IN_ABS_PATH2 = make_abspath(r"inputs-outputs\comparision\compare_document2.docx")
COMPARISION_OUT_ABS_PATH1 = make_abspath(r"betabot\src\assets\comparision-output-doc1.docx")
COMPARISION_OUT_ABS_PATH2 = make_abspath(r"betabot\src\assets\comparision-output-doc2.docx")

HF_EMBEDDINGS = HuggingFaceEmbeddings()

LLM = AutoModelForCausalLM.from_pretrained(MODEL_ABS_PATH, model_type='llama',temperature=0,repetition_penalty=1.2)

PARTY_PROMPT="""follow the Examples to find the buyer and seller from the given input text
Example1: Generate a contract document between buyer Virtous and seller Infosys a sale document considering the commodity oilseeds and origin from India
solution:
buyer-Virtous
seller- Infosys
type- sale
commodity- oilseeds
origin - India

Example2: Write a contract between salesforce and digest a purchase document of grainseeds based in USA
solution:
buyer-Salesforce
seller-digest
type - purchase
commodity-grainseeds
origin - USA

Question:{question}
solution:
"""

PARTY_PROMPT_TEMPLATE = PromptTemplate(template=PARTY_PROMPT, input_variables=["question"])


DOC_PROMPT="""MODIFY the below given content to satisfy the given rules
content:
{content}
rules:
{rules}

modified content:
"""

DOC_PROMPT_TEMPLATE = PromptTemplate(template=DOC_PROMPT, input_variables=["content","rules"])

RULES_PROMPT="""Generate the rules by understanding the given example
Input:{context}
Rules:{rules}

Input:{query_context}
Rules:
"""

RULES_PROMPT_TEMPLATE =PromptTemplate(template=RULES_PROMPT,input_variables=['context','rules','query_context'])
