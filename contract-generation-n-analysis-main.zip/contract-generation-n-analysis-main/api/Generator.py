import os
import requests
from datetime import datetime

# print("Inside Doc-Generator")

from base import CustLLMChain,VectorStore,refine_content,make_docx_file
from constants import (REF_DOCS_VDB_ABS_PATH,
		       		   LLM,
                       HF_EMBEDDINGS,
                       PARTY_PROMPT_TEMPLATE,
                       DOC_PROMPT_TEMPLATE,
					   API_BASE_URL,
					   GEN_OUT_ABS_PATH
                       )

ref_docs_vdb = VectorStore(REF_DOCS_VDB_ABS_PATH,HF_EMBEDDINGS)

def get_party_details(user_input):
	chain=CustLLMChain(llm=LLM,prompt=PARTY_PROMPT_TEMPLATE)
	party_details=chain(question=user_input)
	ignore_list = ["\end{code}","\begin{code}"]
	for ig in ignore_list: party_details = party_details.replace(ig,"")
	return party_details

def make_party_dict(party_details):
	lines = party_details.split("\n")
	party_dict={}
	for line in lines:
		if line.strip() == "": continue
		k,v = line.split("-")
		k = k.strip().lower()
		if k in ["buyer","seller"]: k+="s"
		party_dict[k]=v.strip()
	return party_dict
def format_exception_output(party_dict,section):
	output=""
	section = section.strip().lower()
	if not party_dict.get(section) is None:
		output+= party_dict[section]+"\n"
		if section in ["sellers","buyers","ownerdetails"]:
			output+= "[Address]\n"
	elif section == "contractdate":
		output+= f"{datetime.today().date()}\n"
	return output

def generate_content_section_wise(user_input,template,ref_past_doc,new_rules,log):
	out_secs,out_content=[],[]
	sep="---"*20+"\n"

	doc_gen_chain=CustLLMChain(llm=LLM,prompt=DOC_PROMPT_TEMPLATE)

	res = requests.get(API_BASE_URL+f"get_template/{template}")
	section_names = res.json()["sections"]
	log.write("Sections:\n"+sep+str(section_names))

	start = datetime.now()
	party_details = get_party_details(user_input)
	log.write("Party Details:\n"+sep+party_details+"\n")
	log.write("\tTime taken for party details:"+str(datetime.now()-start)+"\n")

	exception_list = ["ownerdetails","sellers","buyers","contractdate","commodity"]
	party_dict = make_party_dict(party_details)
	log.write(str(party_dict))

	contract_type = party_dict.get("type")
	origin = party_dict.get("origin")
	if origin.strip().lower() in user_input.strip().lower(): exception_list.append("origin")
	if contract_type == "purchase":
		party_dict["ownerdetails"] = party_dict["buyers"]
	else:
		party_dict["ownerdetails"] = party_dict["sellers"]
	
	# output=""
	max_words=None if ref_past_doc else 1000
	cnt=0
	for section in section_names[:]:
		# output+='\n<strong>'+section+":</strong>\n"
		# if cnt==3:break
		if section.strip().lower() in exception_list:
			out=format_exception_output(party_dict,section)
			# output+=out
			out_secs.append(section)
			out_content.append(out)
			continue
		context = ref_docs_vdb.get_section_content(section,template=template,max_words=max_words)
		if not ref_past_doc:
			print("using llm")
			rules = party_details+"\n"+new_rules.get(section.lower().replace(" ",""),"")
			res = doc_gen_chain(rules=rules,content=context)
			res = refine_content(res,party_details)
		else: res = context
		log.write(section+":\n"+sep+res+"\n")
		# output+= res+"\n"
		out_secs.append(section)
		out_content.append(res)
		cnt+=1
	# log.close()
	print("Document Generated. Saving...")
	make_docx_file(GEN_OUT_ABS_PATH,out_secs,out_content)
	return None

def generate_content(user_input,template,new_rules={},ref_past_doc=False,*args,**kwargs):
	if not ref_past_doc: ref_past_doc=True
	log = open("log.txt","w")
	start = datetime.now()
	if len(new_rules)>0:
		new_rules = {k.lower().replace(" ",""):v for k,v in new_rules.items()}
	generate_content_section_wise(user_input,template,ref_past_doc,new_rules,log=log)
	log.write(f"Time taken:{datetime.now()-start}")
	log.close()

	return GEN_OUT_ABS_PATH
