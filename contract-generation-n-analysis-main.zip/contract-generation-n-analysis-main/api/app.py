import os
from flask import Flask, jsonify, request
from flask_restful import Resource,Api
from flask_cors import CORS, cross_origin
import sqlite3

from Generator import generate_content
from Analyser import analyze
from Comparator import comparator
from constants import (DB_ABS_PATH,
                       ANALYSIS_IN_ABS_PATH,
                        COMPARISION_IN_ABS_PATH1,
                        COMPARISION_IN_ABS_PATH2,
                        )

app = Flask(__name__)
app_api = Api(app)
app.config['JSON_SORT_KEYS'] = False
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'


def execute_select_query(query=None,table=None,columns=None):
    if not query:
        if not columns: columns = "*"
        else: columns = ", ".join(columns)
        query = f"SELECT {columns} FROM {table}"
    with sqlite3.connect(DB_ABS_PATH) as conn:
        cursor = conn.cursor()
        cursor.execute(query)
        templates = cursor.fetchall()
        cursor.close()
    return list(templates)

class GetTemplates(Resource):
    @cross_origin()
    def get(self):
        query = "SELECT name FROM templates"
        templates = execute_select_query(query)
        templates = [t[0] for t in templates]
        return jsonify({'templates':templates})

class GetTemplateSections(Resource):
    @cross_origin()
    def get(self,template_name):
        # template_name = template_name.replace(" ","").lower()
        query = f"SELECT id,section_ids FROM templates WHERE name='{template_name}'"
        res = execute_select_query(query)
        template_id,sections = res[0]
        if not sections or not sections[0] or len(sections[0]) == 0:
            return jsonify({'error':f'Template - {template_name} not found'})
        section_ids = [int(k) for k in sections.split(",")]
        query = f"SELECT display_name FROM sections WHERE id IN {tuple(section_ids)};"
        sections = execute_select_query(query)
        sections=[st[0] for st in sections]
        return jsonify({'template_id':template_id,'sections':sections})

class GetSectionRules(Resource):
    @cross_origin()
    def get(self,section_name,all=None):
        print("args:",section_name,",",all)
        section_strip = section_name.replace(" ","").lower()
        section_names = (section_strip,'')
        if all=="all": section_names = (section_strip,"all","text")
        query = f"SELECT id,expressions FROM rules WHERE section IN {section_names}"
        res = execute_select_query(query)
        cols=["rule_id","expressions"]
        rows = [dict(zip(cols,row)) for row in res]
        return jsonify({"section_name":section_name,"rules":rows})
class GetRules(Resource):
    @cross_origin()
    def get(self,id):
        query = f"SELECT expressions FROM rules where id={int(id)}"
        rows = execute_select_query(query)
        return jsonify({"rules":rows[0]})
    
class GenerateContent(Resource):
    @cross_origin()
    def post(self):
        # print("data:",request.data)
        # print("form:",request.form)
        if not request.json:
            return jsonify({'error':'No input data provided or Invalid input data'})
        if 'query' not in request.json:
            return jsonify({'error':'`query` parameter is missing in the request'})
        # doc_type = request.form.get('doc_type')
        # template = request.form['template']
        # custom_rules = request.form['custom_rules']
        data = request.json
        query = data.get('query', '')
        template = data.get('template','')
        ref_past_docs = data.get('refPastDocs',False)
        new_rules = data.get('newRules',{})
        # query = request.data[0]['query ']
        output = generate_content(query,template,new_rules,ref_past_docs)
        # with open(output, 'r') as f:
        #     text = f.read()
        return jsonify({'file':output.split('\\')[-1]})

# resource class for analyzing a document
# @cross_origin()
class AnalyzeDocument(Resource):
    @cross_origin()
    def post(self):
        # print("data:",request.data)
        print("files:",request.files)
        # print(type(request.files['file']))
        if request.files:
            file = request.files['file']
            file.save(ANALYSIS_IN_ABS_PATH)
        else:
            return jsonify({'error':'No input data provided or Invalid input data'})

        doc_type = request.form.get('doc_type')
        res = analyze(ANALYSIS_IN_ABS_PATH,demo=True)
        print("path:",res)
        return jsonify({"file":res})

# resource class for comparing documents
# @cross_origin()
class CompareDocuments(Resource):
    @cross_origin()
    def post(self):
        # print("data:",request.data)
        print("files outside:",request.files)
        print(type(request.data))
        if request.files:
            print("files inside:",request.files)
            file1 = request.files['file1']
            file2 = request.files['file2']   
            file1.save(COMPARISION_IN_ABS_PATH1)
            file2.save(COMPARISION_IN_ABS_PATH2)
        else:
            return jsonify({'error':'No input data provided or Invalid input data'})
        
        doc_type = request.form.get('doc_type')
        res = comparator(COMPARISION_IN_ABS_PATH1,COMPARISION_IN_ABS_PATH2,doc_type)
        # print("path:",output)
        return jsonify({'file1':res[0],'file2':res[1]})

# adding resources to api
app_api.add_resource(GenerateContent,'/generate_content')
app_api.add_resource(AnalyzeDocument,'/analyze_document')
app_api.add_resource(CompareDocuments,'/compare_documents')
app_api.add_resource(GetTemplates,'/get_templates')
app_api.add_resource(GetTemplateSections,'/get_template/<string:template_name>')
app_api.add_resource(GetSectionRules,'/get_section_rules/<string:section_name>/<string:all>','/get_section_rules/<string:section_name>/')
app_api.add_resource(GetRules,'/get_rules/<string:id>')

if __name__ == '__main__':
    app.run(debug=True)