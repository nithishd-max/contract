# contract-generation-n-analysis
STG Makeathon 15: Problem statement: Contract / Document Content Generation and Analysis
